#ifndef _MESI
#define _MESI

#include "HelperFunctions.h"

void MESI (int event, int index, int way, unsigned int address, int *Snoop_Response, int *Bus_Operation, int* Get_Snoop, int* status);

#endif
