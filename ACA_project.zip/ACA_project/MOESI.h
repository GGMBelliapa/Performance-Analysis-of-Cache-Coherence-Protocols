#ifndef _MOESI
#define _MOESI

#include "HelperFunctions.h"

void MOESI (int event, int index, int way, unsigned int address, int *Snoop_Response, int *Bus_Operation, int* Get_Snoop, int* status);

#endif
